package com.example.indoorpositioning;

/**
 * Created by ajnas on 1/11/17.
 */

public class Config {

    public static final String BASE_URL = "http://your-server.url.com";
}
